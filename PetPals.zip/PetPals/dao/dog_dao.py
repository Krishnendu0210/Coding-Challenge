import sqlite3
from entity.dog import Dog
from util.db_conn_util import get_connection

class DogDAO:
    def get_all_dogs(self):
        dogs = []
        try:
            conn = get_connection()
            cursor = conn.cursor()
            query = "SELECT * FROM pets WHERE Type = 'Dog'"
            cursor.execute(query)
            rows = cursor.fetchall()
            for row in rows:
                dog = Dog(name=row[1], age=row[2], breed=row[3], dog_breed=row[5])
                dogs.append(dog)
        except Exception as e:
            print("Error retrieving dogs:", e)
        finally:
            if conn:
                conn.close()
        return dogs

    def add_dog(self, dog: Dog):
        try:
            conn = get_connection()
            cursor = conn.cursor()
            insert_query = """
                INSERT INTO pets (Name, Age, Breed, Type, DogBreed)
                VALUES (?, ?, ?, 'Dog', ?)
            """
            cursor.execute(insert_query, (dog.name, dog.age, dog.breed, dog.dog_breed))
            conn.commit()
            print("Dog added successfully.")
        except Exception as e:
            print("Error adding dog:", e)
        finally:
            if conn:
                conn.close()
