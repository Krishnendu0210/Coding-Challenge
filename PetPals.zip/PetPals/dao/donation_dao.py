from util.db_conn_util import get_connection
from entity.donation import CashDonation, ItemDonation
import sqlite3

class DonationDAO:
    def add_cash_donation(self, donation: CashDonation):
        try:
            conn = get_connection()
            cursor = conn.cursor()
            insert_query = """
                INSERT INTO donations (DonorName, Amount, DonationDate, DonationType)
                VALUES (?, ?, ?, 'Cash')
            """
            cursor.execute(insert_query, (
                donation.donor_name,
                donation.amount,
                donation.donation_date
            ))
            conn.commit()
            print("Cash donation recorded.")
        except Exception as e:
            print("Error recording cash donation:", e)
        finally:
            if conn:
                conn.close()

    def add_item_donation(self, donation: ItemDonation):
        try:
            conn = get_connection()
            cursor = conn.cursor()
            insert_query = """
                INSERT INTO donations (DonorName, ItemType, DonationType)
                VALUES (?, ?, 'Item')
            """
            cursor.execute(insert_query, (
                donation.donor_name,
                donation.item_type
            ))
            conn.commit()
            print("Item donation recorded.")
        except Exception as e:
            print("Error recording item donation:", e)
        finally:
            if conn:
                conn.close()

    def get_all_donations(self):
        donations = []
        try:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM donations")
            rows = cursor.fetchall()
            for row in rows:
                if row[5] == 'Cash':
                    donations.append(CashDonation(row[1], row[2], row[3]))
                elif row[5] == 'Item':
                    donations.append(ItemDonation(row[1], row[4]))
        except Exception as e:
            print("Error retrieving donations:", e)
        finally:
            if conn:
                conn.close()
        return donations
