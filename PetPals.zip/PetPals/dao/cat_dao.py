

import sqlite3
from entity.cat import Cat
from util.db_conn_util import get_connection

class CatDAO:
    def get_all_cats(self):
        cats = []
        try:
            conn = get_connection()
            cursor = conn.cursor()
            query = "SELECT * FROM pets WHERE Type = 'Cat'"
            cursor.execute(query)
            rows = cursor.fetchall()
            for row in rows:
                cat = Cat(name=row[1], age=row[2], breed=row[3], cat_color=row[6])
                cats.append(cat)
        except Exception as e:
            print("Error retrieving cats:", e)
        finally:
            if conn:
                conn.close()
        return cats

    def add_cat(self, cat: Cat):
        try:
            conn = get_connection()
            cursor = conn.cursor()
            insert_query = """
                INSERT INTO pets (Name, Age, Breed, Type, CatColor)
                VALUES (?, ?, ?, 'Cat', ?)
            """
            cursor.execute(insert_query, (cat.name, cat.age, cat.breed, cat.cat_color))
            conn.commit()
            print("Cat added successfully.")
        except Exception as e:
            print("Error adding cat:", e)
        finally:
            if conn:
                conn.close()
