# exception/custom_exceptions.py

class InvalidAgeException(Exception):
    def __init__(self, message="Age must be a positive integer"):
        super().__init__(message)

class NullReferenceException(Exception):
    def __init__(self, message="Pet has missing information"):
        super().__init__(message)

class InsufficientFundsException(Exception):
    def __init__(self, message="Donation must be at least $10"):
        super().__init__(message)

class FileHandlingException(Exception):
    def __init__(self, message="Error reading from file"):
        super().__init__(message)

class AdoptionException(Exception):
    def __init__(self, message="Adoption error occurred"):
        super().__init__(message)
