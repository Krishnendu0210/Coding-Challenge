from util.db_conn_util import DBConnUtil

try:
    conn = DBConnUtil.get_connection()
    print("✅ Connected to the database successfully!")
    conn.close()
except Exception as e:
    print("❌ Connection failed:", e)
