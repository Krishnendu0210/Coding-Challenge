[database]
connection_string = DRIVER={ODBC Driver 17 for SQL Server};SERVER=localhost;DATABASE=PetPalsDB;Trusted_Connection=yes;
