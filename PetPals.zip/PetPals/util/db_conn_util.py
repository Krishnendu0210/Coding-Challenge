import pyodbc

def get_connection():
    try:
        connection = pyodbc.connect(
            'DRIVER={SQL Server};'
            'SERVER=KRISH;'                     # Replace with your actual server name
            'DATABASE=PetPalsDB;'
            'Trusted_Connection=yes;'
        )
        return connection
    except Exception as e:
        print("Error connecting to database:", e)
        raise e


