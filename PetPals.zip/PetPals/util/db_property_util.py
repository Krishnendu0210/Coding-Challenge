import configparser

def get_connection_string(filename: str) -> str:
    config = configparser.ConfigParser()
    config.read(filename)
    return config['database']['connection_string']
