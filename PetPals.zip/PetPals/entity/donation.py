from abc import ABC, abstractmethod
from datetime import date

class Donation(ABC):
    def __init__(self, donor_name: str, amount: float = 0.0):
        self.donor_name = donor_name
        self.amount = amount

    @abstractmethod
    def record_donation(self):
        pass


class CashDonation(Donation):
    def __init__(self, donor_name: str, amount: float, donation_date: date):
        super().__init__(donor_name, amount)
        self.donation_date = donation_date

    def record_donation(self):
        return (f"Cash Donation Recorded: {self.donor_name} donated "
                f"${self.amount:.2f} on {self.donation_date}")


class ItemDonation(Donation):
    def __init__(self, donor_name: str, item_type: str):
        super().__init__(donor_name)
        self.item_type = item_type

    def record_donation(self):
        return (f"Item Donation Recorded: {self.donor_name} donated item: "
                f"{self.item_type}")
