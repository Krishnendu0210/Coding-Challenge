class PetShelter:
    def __init__(self):
        self.available_pets = []

    def add_pet(self, pet):
        self.available_pets.append(pet)
        print(f"✅ Pet '{pet.name}' added to the shelter.")

    def remove_pet(self, pet):
        if pet in self.available_pets:
            self.available_pets.remove(pet)
            print(f"❌ Pet '{pet.name}' removed from the shelter.")
        else:
            print("⚠️ Pet not found in the shelter.")

    def list_available_pets(self):
        if not self.available_pets:
            print("🚫 No pets available for adoption.")
        else:
            print("🐾 Available Pets for Adoption:")
            for pet in self.available_pets:
                print(f" - {pet}")
