from dao.cat_dao import CatDAO
from dao.dog_dao import DogDAO
from dao.donation_dao import DonationDAO
from dao.adoption_event_dao import AdoptionEventDAO
from entity.cat import Cat
from entity.dog import Dog
from entity.donation import CashDonation, ItemDonation
from datetime import datetime
from exception.custom_exceptions import *

cat_dao = CatDAO()
dog_dao = DogDAO()
donation_dao = DonationDAO()
event_dao = AdoptionEventDAO()

def menu():
    while True:
        print("\n====== PetPals Main Menu ======")
        print("1. View All Pets")
        print("2. Add a New Pet (Cat/Dog)")
        print("3. Make a Donation")
        print("4. View Adoption Events")
        print("5. Register for Event")
        print("6. Exit")
        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                view_all_pets()

            elif choice == '2':
                add_new_pet()

            elif choice == '3':
                make_donation()

            elif choice == '4':
                view_events()

            elif choice == '5':
                register_participant()

            elif choice == '6':
                print("Exiting PetPals. Goodbye!")
                break

            else:
                print("Invalid choice. Please try again.")

        except Exception as e:
            print("Error:", e)

def view_all_pets():
    print("\n-- All Cats --")
    for cat in cat_dao.get_all_cats():
        print(cat)

    print("\n-- All Dogs --")
    for dog in dog_dao.get_all_dogs():
        print(dog)

def add_new_pet():
    pet_type = input("Enter type (Cat/Dog): ").strip().lower()

    try:
        name = input("Name: ")
        age = int(input("Age: "))
        if age <= 0:
            raise InvalidAgeException()

        breed = input("Breed: ")

        if pet_type == 'cat':
            color = input("Cat Color: ")
            cat = Cat(name, age, breed, color)
            cat_dao.add_cat(cat)

        elif pet_type == 'dog':
            dog_breed = input("Dog Breed: ")
            dog = Dog(name, age, breed, dog_breed)
            dog_dao.add_dog(dog)

        else:
            print("Invalid pet type.")

    except ValueError:
        print("Age must be a number.")
    except InvalidAgeException as e:
        print(e)

def make_donation():
    donation_type = input("Enter donation type (Cash/Item): ").strip().lower()
    name = input("Donor Name: ")

    try:
        if donation_type == 'cash':
            amount = float(input("Amount: "))
            if amount < 10:
                raise InsufficientFundsException()
            date_str = input("Date (YYYY-MM-DD): ")
            donation_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            donation = CashDonation(name, amount, donation_date)
            donation_dao.add_cash_donation(donation)

        elif donation_type == 'item':
            item = input("Item Type: ")
            donation = ItemDonation(name, item)
            donation_dao.add_item_donation(donation)

        else:
            print("Invalid donation type.")

    except ValueError:
        print("Invalid input format.")
    except InsufficientFundsException as e:
        print(e)

def view_events():
    print("\n-- Upcoming Adoption Events --")
    events = event_dao.get_all_events()
    for e in events:
        print(f"ID: {e['EventID']} | {e['EventName']} on {e['EventDate']} @ {e['Location']}")

def register_participant():
    try:
        event_id = int(input("Enter Event ID to register for: "))
        name = input("Participant Name: ")
        ptype = input("Type (Shelter/Adopter): ")
        event_dao.register_participant(event_id, name, ptype)
    except ValueError:
        print("Event ID must be a number.")

if __name__ == "__main__":
    menu()
